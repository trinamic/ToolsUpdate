This file can be opened through the start menu, "Trinamic Tools" section!

todo:
- im oben genannten Eintrag gibt es die Links zu den installierten Tools (bis jetzt IDE und CANopen)
  welche auch Startmenü angeheftet werden können (gilt nicht für die Taskleiste, da es sich um cmd Dateien handelt)
- Links gibt es auch auf dem Desktop

Mit maintenancetool.exe im gewählten installierten Verzeichnis gäbs Uninstall, Komponenten oder Update(kommt noch)

Dies alles könnte natürlich auch in eine Art Launcher App für TMC Tools fließen.
